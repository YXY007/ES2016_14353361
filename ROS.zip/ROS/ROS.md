<h1>ROS Installation</h1>
<p>Robot Operating System provides libraries and tools to help software developers create robot applications. It provides hardware abstraction, device drivers, libraries, visualizers, message-passing, package management, and more. ROS is licensed under an open source, BSD license. </p>
<h2>Installation</h2>
---
<h3>Setup sources.list</h3>
<p>Type in the following codes to set up the computer to accept software from packages.ros.org. ROS Indigo ONLY supports Saucy (13.10) and Trusty (14.04) for debian packages. </p>
	sudo sh -c 'echo "deb http://packages.ros.org/ros/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/ros-latest.list'

<h3>Set up the keys</h3>
<p>Type in the following commands</p>
	sudo apt-key adv --keyserver hkp://ha.pool.sks-keyservers.net --recv-key 0xB01FA116

<h3>Install</h3>
<p>Make sure the Debian package index is up-to-date. It takes times here.</p>
	sudo apt-get update

<p>Then install the ROS. Remember to choose the Desktop-Full one.</p>
<p>It includes the following libs: ROS, rqt, rviz, robot-generic libraries, 2D/3D simulators and 2D/3D perception.</p>
	sudo apt-get install ros-indigo-desktop-full

<p>If the installation fails because of the broken packages, try to change the source.</p> 
![](couldnot.png)
<p>After changing the source, the installation is complete.</p>
![](full.png)
<p>After installation, find available packages using the following command</p>
	apt-cache search ros-indigo

<p>And you will see response like this</p>
![](find.png)

<h3>Initialize rosdep</h3>
<p>rosdep makes it easy to install system dependencies for source needed to compile and is required to run some core components in ROS. And the commands to initialize it is as follow</p>
	sudo rosdep init
	rosdep update

![](rosdep.png)
<h3>Environment setup</h3>
<p>It's convenient if the ROS environment variables are automatically added to bash session every time a new shell is launched</p>
	echo "source /opt/ros/indigo/setup.bash" >> ~/.bashrc
source ~/.bashrc
	source /opt/ros/indigo/setup.bash
	echo "source /opt/ros/indigo/setup.zsh" >> ~/.zshrc
	source ~/.zshrc

<h3>Getting rosinstall</h3>
<p>rosinstall is a frequently used command-line tool in ROS that is distributed separately. It makes it easy download many source trees for ROS packages with one command. </p>
	sudo apt-get install python-rosinstall

![](rosinstall.png)
<p>After all of this the ROS has been successfully installed.</p>